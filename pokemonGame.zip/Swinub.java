

class Swinub extends Pokemon{
	public Swinub(String name, float weight, float stepLength){
		super(name, weight, stepLength, 1f, new String[] {"Ice, Ground"});
	}
}
